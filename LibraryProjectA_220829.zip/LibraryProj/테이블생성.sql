use library;
CREATE TABLE student(
	std_no INTEGER primary key,
    std_name VARCHAR(20)  not null,
	major VARCHAR(40) not null,
    age INTEGER  not null,
    rsv_cnt INTEGER not null,
    brrw_cnt INTEGER not null,
    stop_date VARCHAR(8) not null,
    insert_time timestamp default current_timestamp not null
);

CREATE TABLE book(
	book_no INTEGER primary key,
    book_name VARCHAR(50) not null,
    author VARCHAR(20) not null,
    price INTEGER not null,
    prch_date VARCHAR(8) not null,
    rsv_people INTEGER not null,
    brrw_yn CHAR(1) not null,
    insert_time timestamp default current_timestamp not null
);


CREATE TABLE ledger(
	seq INTEGER auto_increment primary key,
    brrw_date VARCHAR(8) not null,
    exp_date VARCHAR(8) not null,
    std_no INTEGER not null,
    book_no INTEGER not null,
    rtrn_date VARCHAR(8) not null,
    rtrn_yn CHAR(1) not null,
    insert_time timestamp default current_timestamp not null
);


CREATE TABLE reservation(
	seq INTEGER auto_increment primary key,
    rsv_date VARCHAR(8) not null,
    std_no INTEGER not null,
    book_no INTEGER not null,
    rsv_yn VARCHAR(1) not null,
    insert_time timestamp default current_timestamp not null
);

CREATE TABLE config(
	seq INTEGER auto_increment primary key,
    brrw_period INTEGER default 7 not null,
    brrw_max INTEGER default 5 not null,
    stdrsv_max INTEGER default 3 not null,
    bookrsv_max INTEGER default 2 not null,
    pw VARCHAR(20) default '0000' not null,
    insert_time timestamp default current_timestamp not null
    
);

desc student;
desc book;
desc ledger;
desc reservation; 
desc config;

select * from book;
select * from student;
select * from ledger;
select * from reservation;
select * from config;

insert into config(brrw_period,brrw_max,stdrsv_max,bookrsv_max,pw) value(7,5,3,2,'0000');
select * from config order by insert_time desc limit 1;

update student set brrw_cnt = brrw_cnt + 1 where std_no = 20170123;
drop table config;