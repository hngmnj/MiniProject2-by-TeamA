package test;

public class BookVO {

	private int bkNo;
	private String bkName;
	private String author;
	private int price;
	private String prchDate; // 구입일
	private int rsvPeople; // 예약인원수
	private String brrwYN; // 대여가능여부

	public BookVO() {
	}
	
	public BookVO(int bkNo, String bkName, String author, int price, String prchDate) {
		this.bkNo = bkNo;
		this.bkName = bkName;
		this.author = author;
		this.price = price;
		this.prchDate = prchDate;
	}
	public BookVO(int bkNo, String bkName, String author, int price, String prchDate, int rsvPeople, String brrwYN) {
		this.bkNo = bkNo;
		this.bkName = bkName;
		this.author = author;
		this.price = price;
		this.prchDate = prchDate;
		this.rsvPeople = rsvPeople;
		this.brrwYN = brrwYN;
	}

	public BookVO(String data) {

		System.out.println(data);
		String[] temp = data.split(",");
		this.bkNo = Integer.parseInt(temp[1].trim());
		this.bkName = temp[2].trim();
		this.author = temp[3].trim();
		this.price = Integer.parseInt(temp[4].trim());
		this.prchDate = temp[5].trim();
		this.rsvPeople = Integer.parseInt(temp[6].trim());
		this.brrwYN = temp[7].trim();
	}

	public int getBkNo() {
		return bkNo;
	}

	public void setBkNo(int bkNo) {
		this.bkNo = bkNo;
	}

	public String getBkName() {
		return bkName;
	}

	public void setBkName(String bkName) {
		this.bkName = bkName;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getPrchDate() {
		return prchDate;
	}

	public void setPrchDate(String prchDate) {
		this.prchDate = prchDate;
	}

	public int getRsvPeople() {
		return rsvPeople;
	}

	public void setRsvPeople(int rsvPeople) {
		this.rsvPeople = rsvPeople;
	}

	public String getBrrwYN() {
		return brrwYN;
	}

	public void setBrrwYN(String brrwYN) {
		this.brrwYN = brrwYN;
	}

}
