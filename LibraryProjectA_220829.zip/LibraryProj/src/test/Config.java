package test;

import java.sql.SQLException;

public class Config {
	
	LibraryDAO dao = new LibraryDAO();

	public ConfigVO getConfig() throws SQLException {
		ConfigVO config = dao.selectConfig();
		return config;
	}
	
	public boolean setConfig(ConfigVO vo) throws SQLException {
		boolean flag = dao.insertConfig(vo);
		return flag;
	}

}
