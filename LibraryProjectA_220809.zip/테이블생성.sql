use library;
CREATE TABLE student(
	std_no INTEGER primary key,
    std_name VARCHAR(20)  not null,
	major VARCHAR(40) not null,
    age INTEGER  not null,
    rsv_cnt INTEGER not null,
    brrw_cnt INTEGER not null,
    stop_date VARCHAR(8) not null,
    insert_time timestamp default current_timestamp not null
);

CREATE TABLE book(
	book_no INTEGER primary key,
    book_name VARCHAR(50) not null,
    author VARCHAR(20) not null,
    price INTEGER not null,
    prch_date VARCHAR(8) not null,
    rsv_people INTEGER not null,
    brrw_yn CHAR(1) not null,
    insert_time timestamp default current_timestamp not null
);


CREATE TABLE ledger(
	seq INTEGER auto_increment primary key,
    brrw_date VARCHAR(8) not null,
    exp_date VARCHAR(8) not null,
    std_no INTEGER not null,
    book_no INTEGER not null,
    rtrn_date VARCHAR(8) not null,
    rtrn_yn CHAR(1) not null,
    insert_time timestamp default current_timestamp not null
);


CREATE TABLE reservation(
	seq INTEGER auto_increment primary key,
    rsv_date VARCHAR(8) not null,
    std_no INTEGER not null,
    book_no INTEGER not null,
    rsv_yn VARCHAR(1) not null,
    insert_time timestamp default current_timestamp not null
);

desc student;
desc book;
desc ledger;
desc reservation; 

select * from book;
select * from student;
select * from ledger;
select * from reservation;

update student set brrw_cnt = brrw_cnt + 1 where std_no = 20170123;