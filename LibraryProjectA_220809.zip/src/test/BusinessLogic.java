package test;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class BusinessLogic {
	
		// 0. CSV파일 입력 (csv -> DB)
		public void csvToDB() throws IOException, SQLException {
			CsvReader cr = new CsvReader();
			cr.BookReader();
			cr.StudentReader();
		}
	
		// 1-1. 도서 목록
		public void bookList() throws SQLException {
			LibraryDAO dao = new LibraryDAO();
			ArrayList<BookVO> list =  dao.selectBook();
			System.out.println("책 번호\t|\t책 이름\t\t|\t저자\t|\t대여 가능 여부\t");
			for(BookVO vo : list) {
				System.out.println(vo.getBkNo()+"\t\t"+vo.getBkName()+"\t\t"+vo.getAuthor()+"\t\t"+vo.getBrrwYN());
			}
			System.out.println("");
		}
		
		// 1-2. 도서 등록
		public void bookAdd() throws SQLException {
			Scanner sc = new Scanner(System.in);
			LibraryDAO dao = new LibraryDAO();
			ArrayList<BookVO> list = new ArrayList<BookVO>();
			while (true) {
	            System.out.println("등록할 신규 도서번호를 입력해주세요 >>>");
	            int bkNo = Integer.parseInt(sc.nextLine());
	            String bkName;
	            String author;
	            int price;
	            String prchDate;
	            boolean flag;
	            System.out.println("제목 입력 >>>");
	            bkName = sc.nextLine();
	            System.out.println("지은이 입력 >>>");
	            author = sc.nextLine();
	            System.out.println("가격 입력 >>>");
	            price = Integer.parseInt(sc.nextLine());
	            System.out.println("구매날짜 입력(yyyyMMdd) >>>");
	            prchDate = sc.nextLine();
	            BookVO vo = new BookVO(bkNo, bkName, author, price, prchDate, 0, "Y");
	            list.add(vo);
	            flag = dao.BookInsert(list);
	            if (flag) {
	            	System.out.println("도서 등록 완료");
	            	break;
	            } else {
	            	System.out.println("해당 도서가 존재하지 않습니다. 도서 번호를 다시 입력하세요.");
	            }  
	        } 
		}
		
		// 1-3.책 정보 수정
	    public void updateBook() throws SQLException {
	    	Scanner sc = new Scanner(System.in);
	    	LibraryDAO dao = new LibraryDAO();
	        while (true) {
	            System.out.println("수정 할 책의 번호를 입력해주세요 >>>");
	            int bkNo = Integer.parseInt(sc.nextLine());
	            String bkName;
	            String author;
	            boolean flag;
	            System.out.println("제목 입력 >>>");
	            bkName = sc.nextLine();
	            System.out.println("지은이 입력 >>>");
	            author = sc.nextLine();
	            flag = dao.updateBookInfo(bkNo, bkName, author);
	            if (flag) {
	            	System.out.println("도서 수정 완료");
	            	break;
	            } else {
	            	System.out.println("해당 도서가 존재하지 않습니다. 도서 번호를 다시 입력하세요.");
	            }  
	        } 
	    }
	        
	    // 2.도서대여
		public void borrowBook(int stdNo, int bkNo) throws SQLException {
			BorrowBook bb = new BorrowBook(stdNo, bkNo);
			boolean borrowable = false;
	
			borrowable = bb.checkBan();
			if (borrowable) {
				bb.borrowCancell();
				System.out.println("대출정지된 학생입니다.");
			} else {
				borrowable = bb.checkUnreturn();
				if (borrowable) {
					bb.borrowCancell();
					System.out.println("미반납도서 중 연체도서가 있습니다.");
				} else {
					borrowable = bb.checkBrrwAble();
					if (!borrowable) {
						bb.borrowCancell();
						System.out.println("도서대여는 5권까지 가능합니다.");
					} else {
						borrowable = bb.checkHaveBook();
						if (borrowable) {
							bb.borrowConfirm();
							System.out.println("도서대여가 완료되었습니다.");
						} else {
							System.out.println("해당 도서는 모두 대여중 입니다. 예약하시겠습니까?  >> Y/N");
							Scanner scan = new Scanner(System.in);
							String choice = scan.nextLine();
							if (choice.toUpperCase().equals("Y")) {
								Boolean reservationable = false;
								ReservationBook rb = new ReservationBook(stdNo, bkNo);
								reservationable = rb.checkRsvCnt();
								if (!reservationable) {
									rb.reservationCancell();
									System.out.println("도서예약은 3권까지 가능합니다.");
								} else {
									reservationable = rb.checkRsvPeople();
									if (!reservationable) {
										rb.reservationCancell();
										System.out.println("해당 도서의 예약인원은 2명까지 가능합니다.");
									} else {
										reservationable = rb.checkBrrwOrRsv();						
										if (reservationable) {
											rb.reservationCancell();
											System.out.println("학생이 해당 도서를 이미 대여 또는 예약 중 입니다.");
										} else {
											rb.reservationConfirm();
											System.out.println("도서예약이 완료되었습니다.");
										}
									}
								}
							} else if (choice.equals("N")) {
								bb.borrowCancell();
								System.out.println("도서 대여 및 예약이 취소되었습니다.");
							}
						}
					}
				}
			}
		}
		
		// 3.도서 반납
		public void returnBook(int stdNo, int bkNo) throws SQLException {
			ReturnBook rb = new ReturnBook(stdNo, bkNo);
			boolean unborrowable = rb.checkUnreturn();
			boolean returnable = rb.checkHaveBook();
			
			if (!unborrowable) {
				if (returnable) {
					System.out.println("도서반납이 완료되었습니다.");
					rb.returnConfirm();
				}
			} else {
				unborrowable = rb.checkBan();
				if (unborrowable) {
					System.out.println("대출정지일자가 갱신되었습니다.");
					rb.updateBan();
					rb.returnConfirm();
				} else {
					System.out.println("대출정지일자가 추가되었습니다.");
					rb.newBan();
					rb.returnConfirm();
				}
			}
	
		}
}
