package test;

public class ReservationVO { //예약장부
	
	private int seq; //예약번호
    private String rsvDate; //예약일
    private int stdNo;
    private int bkNo;
    private String rsvYN; //예약여부
    
    public ReservationVO() {}
    
    public ReservationVO(int seq, String rsvDate, int stdNo, int bkNo, String rsvYN) {
    	
    	this.seq = seq;
    	this.rsvDate = rsvDate;
    	this.stdNo = stdNo;
    	this.bkNo = bkNo;
    	this.rsvYN = rsvYN;
    }

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getRsvDate() {
		return rsvDate;
	}

	public void setRsvDate(String rsvDate) {
		this.rsvDate = rsvDate;
	}

	public int getStdNo() {
		return stdNo;
	}

	public void setStdNo(int stdNo) {
		this.stdNo = stdNo;
	}

	public int getBkNo() {
		return bkNo;
	}

	public void setBkNo(int bkNo) {
		this.bkNo = bkNo;
	}

	public String getRsvYN() {
		return rsvYN;
	}

	public void setRsvYN(String rsvYN) {
		this.rsvYN = rsvYN;
	}


}
