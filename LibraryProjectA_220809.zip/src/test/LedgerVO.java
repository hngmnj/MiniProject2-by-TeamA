package test;

public class LedgerVO { //대출장부
	
	private int seq; //대출분류번호
    private String brrwDate; //대출일
    private String expDate; //반납예정일
    private int stdNo;
    private int bkNo;
    private String rtrnDate; //반납일
    private String rtrnYN; //반납여부
    
    public LedgerVO() {}
    
    public LedgerVO(int seq,String brrwDate,String expDate,int stdNo,int bkNo,String rtrnDate,String rtrnYN) {
    	
    	this.seq = seq;
    	this.brrwDate = brrwDate;
    	this.expDate = expDate;
    	this.stdNo = stdNo;
    	this.bkNo = bkNo;
    	this.rtrnDate = rtrnDate;
        this.rtrnYN = rtrnYN;
    }
    
    public LedgerVO(String data) {
    	
    	String[] temp = data.split(",");
    	
    	this.seq = Integer.parseInt(temp[0].trim());
    	this.brrwDate = temp[1].trim();
    	this.expDate = temp[2].trim();
    	this.stdNo = Integer.parseInt(temp[3].trim());
    	this.bkNo = Integer.parseInt(temp[4].trim());
    	this.rtrnDate = temp[5].trim();
        this.rtrnYN = temp[6].trim();
    }

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getBrrwDate() {
		return brrwDate;
	}

	public void setBrrwDate(String brrwDate) {
		this.brrwDate = brrwDate;
	}

	public String getExpDate() {
		return expDate;
	}

	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}

	public int getStdNo() {
		return stdNo;
	}

	public void setStdNo(int stdNo) {
		this.stdNo = stdNo;
	}

	public int getBkNo() {
		return bkNo;
	}

	public void setBkNo(int bkNo) {
		this.bkNo = bkNo;
	}

	public String getRtrnDate() {
		return rtrnDate;
	}

	public void setRtrnDate(String rtrnDate) {
		this.rtrnDate = rtrnDate;
	}

	public String getRtrnYN() {
		return rtrnYN;
	}

	public void setRtrnYN(String rtrnYN) {
		this.rtrnYN = rtrnYN;
	}

	
    
}
