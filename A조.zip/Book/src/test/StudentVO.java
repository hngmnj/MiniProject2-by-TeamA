package test;

public class StudentVO {

	private int stdNo;
	private String stdName;
	private String major;
	private int age;
	private int rsvCnt; //예약권수
	private int brrwCnt; //대출권수
	private String stopDate; //대출정지기간
	
	public StudentVO() {}
	
	public StudentVO(int stdNo, String stdName, String major, int age, int rsvBks, int brrwCnt, String stopDate) {
		
		this.stdNo = stdNo;
		this.stdName = stdName;
		this.major = major;
		this.age = age;
		this.rsvCnt = rsvBks; 
		this.brrwCnt = brrwCnt; 
		this.stopDate = stopDate;
	}
	
	public StudentVO(String data) {
		
		String[] temp = data.split(",");
		this.stdNo = Integer.parseInt(temp[0].trim());
		this.stdName = temp[1].trim();
		this.major = temp[2].trim();
		this.age = Integer.parseInt(temp[3].trim());
		this.rsvCnt = Integer.parseInt(temp[4].trim());
		this.brrwCnt = Integer.parseInt(temp[5].trim());
		this.stopDate = temp[6].trim();
	}

	public int getStdNo() {
		return stdNo;
	}

	public void setStdNo(int stdNo) {
		this.stdNo = stdNo;
	}

	public String getStdName() {
		return stdName;
	}

	public void setStdName(String stdName) {
		this.stdName = stdName;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getRsvCnt() {
		return rsvCnt;
	}

	public void setRsvCnt(int rsvCnt) {
		this.rsvCnt = rsvCnt;
	}

	public int getBrrwCnt() {
		return brrwCnt;
	}

	public void setBrrwCnt(int brrwCnt) {
		this.brrwCnt = brrwCnt;
	}

	public String getStopDate() {
		return stopDate;
	}

	public void setStopDate(String stopDate) {
		this.stopDate = stopDate;
	}

}
