package Day1;

public class LedgerVO {// 대출장부
	
	private int seq; // 대출번호
    private String brrwDate;
    private String expDate; // 반납예정일
    private int stdNo;
    private int bkNo;
    private String rtrnDate; // 반납일
    private String rtrnYN; // 반납여부
    
    public LedgerVO() {}
    
    public LedgerVO(int seq,String loan_date,String exp_return_date,int std_no,int book_no,String return_date,String return_yn) {
    	
    	this.seq = seq;
    	this.brrwDate = loan_date;
    	this.expDate = exp_return_date;
    	this.stdNo = std_no;
    	this.bkNo = book_no;
    	this.rtrnDate = return_date;
        this.rtrnYN = return_yn;
    }
    
    public LedgerVO(String data) {
    	
    	String[] temp = data.split(",");
    	
    	this.seq = Integer.parseInt(temp[0].trim());
    	this.brrwDate = temp[1].trim();
    	this.expDate = temp[2].trim();
    	this.stdNo = Integer.parseInt(temp[3].trim());
    	this.bkNo = Integer.parseInt(temp[4].trim());
    	this.rtrnDate = temp[5].trim();
        this.rtrnYN = temp[6].trim();
    }

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getBrrwDate() {
		return brrwDate;
	}

	public void setBrrwDate(String brrwDate) {
		this.brrwDate = brrwDate;
	}

	public String getExpDate() {
		return expDate;
	}

	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}

	public int getStdNo() {
		return stdNo;
	}

	public void setStdNo(int stdNo) {
		this.stdNo = stdNo;
	}

	public int getBkNo() {
		return bkNo;
	}

	public void setBkNo(int bkNo) {
		this.bkNo = bkNo;
	}

	public String getRtrnDate() {
		return rtrnDate;
	}

	public void setRtrnDate(String rtrnDate) {
		this.rtrnDate = rtrnDate;
	}

	public String getRtrnYN() {
		return rtrnYN;
	}

	public void setRtrnYN(String rtrnYN) {
		this.rtrnYN = rtrnYN;
	}

	
    
}
