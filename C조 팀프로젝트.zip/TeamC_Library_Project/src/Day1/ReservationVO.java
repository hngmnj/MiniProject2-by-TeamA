package Day1;
// 예약장부
public class ReservationVO {
	
	private int seq; //예약번호
    private String rsvDate; // 예약일
    private int stdNo;
    private int bkNo;
    private String rsvYN; // 예약여부
    
    public ReservationVO() {}
    
    public ReservationVO(int seq,String rsvs_date,int std_no,int book_no,String rsvs_yn) {
    	
    	this.seq = seq;
    	this.rsvDate = rsvs_date;
    	this.stdNo = std_no;
    	this.bkNo = book_no;
    	this.rsvYN = rsvs_yn;
    }

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getRsvDate() {
		return rsvDate;
	}

	public void setRsvDate(String rsvDate) {
		this.rsvDate = rsvDate;
	}

	public int getStdNo() {
		return stdNo;
	}

	public void setStdNo(int stdNo) {
		this.stdNo = stdNo;
	}

	public int getBkNo() {
		return bkNo;
	}

	public void setBkNo(int bkNo) {
		this.bkNo = bkNo;
	}

	public String getRsvYN() {
		return rsvYN;
	}

	public void setRsvYN(String rsvYN) {
		this.rsvYN = rsvYN;
	}


}
