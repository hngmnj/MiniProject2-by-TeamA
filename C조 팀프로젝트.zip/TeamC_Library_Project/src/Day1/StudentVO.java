package Day1;

public class StudentVO {

	private int stdNo;
	private String stdName;
	private String major;
	private int age;
	private int rsvBks; //예약 권수
	private int brrwCnt; //대출 권수
	private String stopDate;
	
	public StudentVO() {}
	
	public StudentVO(int std_no,String std_name,String major,int age,int rsvs_cnt,int loan_cnt,String stop_date) {
		
		this.stdNo = std_no;
		this.stdName = std_name;
		this.major = major;
		this.age = age;
		this.rsvBks = rsvs_cnt; 
		this.brrwCnt = loan_cnt; 
		this.stopDate = stop_date; // 정지기간
	}
	
	public StudentVO(String data) {
		
		String[] temp = data.split(",");
		this.stdNo = Integer.parseInt(temp[0].trim());
		this.stdName = temp[1].trim();
		this.major = temp[2].trim();
		this.age = Integer.parseInt(temp[3].trim());
		this.rsvBks = Integer.parseInt(temp[4].trim());
		this.brrwCnt = Integer.parseInt(temp[5].trim());
		this.stopDate = temp[6].trim();
	}

	public int getStdNo() {
		return stdNo;
	}

	public void setStdNo(int stdNo) {
		this.stdNo = stdNo;
	}

	public String getStdName() {
		return stdName;
	}

	public void setStdName(String stdName) {
		this.stdName = stdName;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getRsvBks() {
		return rsvBks;
	}

	public void setRsvBks(int rsvBks) {
		this.rsvBks = rsvBks;
	}

	public int getBrrwCnt() {
		return brrwCnt;
	}

	public void setBrrwCnt(int brrwCnt) {
		this.brrwCnt = brrwCnt;
	}

	public String getStopDate() {
		return stopDate;
	}

	public void setStopDate(String stopDate) {
		this.stopDate = stopDate;
	}

}
