package Day1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

public class csvInsert {
	
	public static void StudentInsert(ArrayList<StudentVO> list) throws SQLException {
		
		String sql = "insert into studentTBL(std_no,std_name,major,age,rsvs_cnt,loan_cnt,stop_date) "
				+ "values(?,?,?,?,?,?,?)";
		
		Connection con = ConnectionManager.getConnection();
		
		PreparedStatement pstmt = con.prepareStatement(sql);
		
		for(StudentVO vo : list) {
			
			pstmt.setInt(1,vo.getStdNo());
			pstmt.setString(2, vo.getStdName());
			pstmt.setString(3, vo.getMajor());
			pstmt.setInt(4, vo.getAge());
			pstmt.setInt(5, vo.getRsvBks());
			pstmt.setInt(6, vo.getBrrwCnt());
			pstmt.setString(7,vo.getStopDate());
			
			boolean flag = pstmt.execute();
			
			if(!flag) {
				System.out.println("입력완료");
			} else {
				System.out.println("입력실패");
			}
		}
	}
	
	public static void BookInsert(ArrayList<BookVO> list) throws SQLException {
		
		String sql = "insert into bookTBL(book_no,book_name,writer,price,pay_date,rsvs_people,loan_yn) "
				+ "values(?,?,?,?,?,?,?)";
		
		Connection con = ConnectionManager.getConnection();
		
		PreparedStatement pstmt = con.prepareStatement(sql);
		
		for(BookVO vo : list) {
			
			pstmt.setInt(1,vo.getBkNo());
			pstmt.setString(2, vo.getBkName());
			pstmt.setString(3, vo.getAuthor());
			pstmt.setInt(4, vo.getPrice());
			pstmt.setString(5, vo.getPrchDate());
			pstmt.setInt(6, vo.getRsvCount());
			pstmt.setString(7,vo.getBrrwYN());
			
			boolean flag = pstmt.execute();
			
			if(!flag) {
				System.out.println("입력완료");
			} else {
				System.out.println("입력실패");
			}
		}
		
	}
}
