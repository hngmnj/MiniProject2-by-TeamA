package test;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

public class LibraryMain {
	
	static BusinessLogic bl = new BusinessLogic();
	static ConfigVO config = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LibraryMain lm = new LibraryMain();
		
		// config 로드(대출기간, 최대대여권수, 학생당예약가능권수 등의 설정값)
		Config cf = new Config();
		try {
			config = cf.getConfig();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//메인 UI실행
		try {
		lm.libUI();
		} catch (SQLException e) {
		e.printStackTrace();
		}
		
		
		// CSV -> DB // CsvReader에서 CSV파일 경로 수정해주고 실행할것.
//		BusinessLogic bl = new BusinessLogic();
//		try {
//			bl.csvToDB();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
	}
	
	public void libUI() throws SQLException {
		Scanner scan = new Scanner(System.in);
		boolean isStop = false;
		int bkNo;
		int stdNo;
		while (!isStop) {
			System.out.println("MAIN-------------------------------------------------");
			System.out.println("| 1. 도서관리 | 2. 대여/반납 | 3. 회원관리 | 4. 설정 | 5. 종료 |");
			System.out.println("-----------------------------------------------------");
			System.out.print("메뉴 중 하나를 선택하세요 >>> ");
			int cmd1 = scan.nextInt();
			System.out.println("");
			// 선택에 맞는 작업을 한다.
			switch(cmd1) {
			case 1:
				boolean isStop1 = false;
				while (!isStop1) {
					System.out.println("1.도서정보----------------------------------------");
					System.out.println("| 1. 도서현황 | 2. 도서등록 | 3. 책정보수정 | 4. 뒤로가기 |");
					System.out.println("------------------------------------------------");
					System.out.print("메뉴 중 하나를 선택하세요 >>> ");
					int cmd2 = scan.nextInt();
					switch(cmd2) {
					case 1:
						bl.bookList();
						break;
					case 2:
						bl.addBook();
						break;
					case 3:
						bl.updateBook();
						System.out.println("");
						break;
					case 4:
						System.out.println("");
						isStop1 = true;
						break;
					}
				}		
				break;
				
			case 2:
				boolean isStop2 = false;
				while (!isStop2) {
					System.out.println("2.대여/반납--------------------------------------");
					System.out.println("| 1. 도서대여 | 2. 도서반납 | 3. 대여현황 | 4. 뒤로가기 |");
					System.out.println("----------------------------------------------");
					System.out.print("메뉴 중 하나를 선택하세요 >>> ");
					int cmd2 = scan.nextInt();
					switch(cmd2) {
					case 1:
						System.out.println("도서 목록-------------------------------");
						bl.bookList();
						System.out.println("대여하실 책의 번호를 입력해주세요>>");
						bkNo = scan.nextInt();
						System.out.println("학생번호를 입력해주세요 >>");
						stdNo = scan.nextInt();
						bl.borrowBook(stdNo, bkNo);
						break;
					case 2:
						System.out.println("도서반납.");
						System.out.println("");
						System.out.println("반납하실 책의 번호를 입력해주세요>>");
						bkNo = scan.nextInt();
						System.out.println("학생번호를 입력해주세요 >>");
						stdNo = scan.nextInt();
						bl.returnBook(stdNo, bkNo);
						break;
					case 3:
						bl.ledgerStatus();
						break;
					case 4:
						System.out.println("");
						isStop2 = true;
						break;
					}
				}		
				break;
				
			case 3:
				boolean isStop3 = false;
				while (!isStop3) {
					System.out.println("3.회원관리------------------------------------------");
					System.out.println("| 1. 회원현황 | 2. 회원등록 | 3. 회원정보수정 | 4. 뒤로가기 |");
					System.out.println("-------------------------------------------------");
					System.out.print("메뉴 중 하나를 선택하세요 >>> ");
					int cmd2 = scan.nextInt();
					switch(cmd2) {
					case 1:
						bl.selectStudentAll();
						break;
					case 2:
						System.out.println("등록할 학생의 학번입력 >>");
						stdNo = scan.nextInt();
						scan.nextLine();
						System.out.println("학생의 변경된 이름 입력 >>");
						String stdName = scan.nextLine();
						System.out.println("학생의 변경된 전공 입력 >>");
						String major = scan.nextLine();
						System.out.println("학생의 변경된 나이 입력 >>");
						int age = scan.nextInt();
						bl.registStd(stdNo, stdName, major, age);
						break;
					case 3:
						System.out.println("수정할 학생의 학번입력 >>");
						stdNo = scan.nextInt();
						scan.nextLine();
						System.out.println("학생의 변경된 이름 입력 >>");
						stdName = scan.nextLine();
						System.out.println("학생의 변경된 전공 입력 >>");
						major = scan.nextLine();
						System.out.println("학생의 변경된 나이 입력 >>");
						age = scan.nextInt();
						bl.editStd(stdNo, stdName, major, age);
						break;
					case 4:
						System.out.println("");
						isStop3 = true;
						break;
					}
				}		
				break;
				
			case 4:
				boolean isStop4 = false;
				while (!isStop4) {
					System.out.println("4.설정------------------------------");
					System.out.println("| 1. 이용현황 | 2. 환경설정 | 3. 뒤로가기 |");
					System.out.println("-----------------------------------");
					System.out.print("메뉴 중 하나를 선택하세요 >>> ");
					int cmd2 = scan.nextInt();
					switch(cmd2) {
					case 1:
						System.out.println("\n1. 대출 도서 상위 5위에 대한 정보");
						System.out.println("2. 대출자 상위 5위에 대한 정보 ");
						System.out.println("3. 대출기간이 가장 짧은 도서에 대한 정보");
						System.out.println("4. 대출반납이 가장 빠른 학생");
						System.out.println("5. 대출을 가장 많이하는 학과");
						System.out.println("6. 대출반납이 가장 늦은 학과");
						System.out.println("7. 종료.");
						System.out.println("메뉴 중 하나를 선택하세요 >>> ");
						int cmd3 = scan.nextInt();
						switch(cmd3) {
						case 1:
							isStop4 = true;
							System.out.println("대출 도서 상위 5위에 대한 정보");
							break;
						case 2:
							isStop4 = true;
							System.out.println("대출자 상위 5위에 대한 정보");
							break;
						case 3:
							isStop4 = true;
							System.out.println("대출기간이 가장 짧은 도서에 대한 정보");
							break;
						case 4:
							isStop4 = true;
							System.out.println("대출반납이 가장 빠른 학생");
							break;
						case 5:
							isStop4 = true;
							System.out.println("대출을 가장 많이하는 학과");
							break;
						case 6:
							isStop4 = true;
							System.out.println("대출반납이 가장 늦은 학과");
							break;
						case 7:
							isStop4 = true;
							break;
						}
						break;
					case 2:
						System.out.println("\n---환경설정---");
						System.out.println("도서 대여 기간 :"+config.getBrrw_period()+"일");
						System.out.println("학생 당 동시 최대 대여 권 수 :"+config.getBrrw_max()+"권");
						System.out.println("학생 당 예약 가능 권 수 :"+config.getStdrsv_max()+"권");
						System.out.println("도서 당 예약 가능 인원 :"+config.getBookrsv_max()+"명");
						System.out.println("설정을 변경하시겠습니까? [Y/N] >>");
						String choice = scan.nextLine();
						choice = scan.nextLine();
						if(choice.toUpperCase().equals("Y")) {
							System.out.println("비밀번호를 입력해주세요 >>");
							String pw = scan.nextLine();
							if(pw.equals(config.getPw())) {
								Config cf = new Config();
								System.out.println("도서 대여 기간 설정 >>");
								int brrwPeriod = scan.nextInt();
								System.out.println("학생 당 동시 최대 대여 권 수 설정 >>");
								int brrwMax = scan.nextInt();
								System.out.println("학생 당 예약 가능 권 수 설정 >>");
								int stdrsvMax = scan.nextInt();
								System.out.println("도서 당 예약 가능 인원 설정 >>");
								int bookrsvMax = scan.nextInt();
								scan.nextLine();
								System.out.println("관리자 패스워드 설정 >>");
								String setPw = scan.nextLine();
								boolean flag = bl.setConfig(brrwPeriod, brrwMax, stdrsvMax, bookrsvMax, setPw);
								if (flag) {
									System.out.println("환경설정 변경을 성공하였습니다.");
								} else {
									System.out.println("환경설정 변경을 실패하였습니다..");
								}
								config = cf.getConfig();
								} else {
									System.out.println("비밀번호가 틀렸습니다");
								}
						} 
						break;
					case 3:
						System.out.println("");
						isStop4 = true;
						break;
					}
				}		
				break;
				
			case 5:
				isStop = true;
				System.out.println("이용해주셔서 감사합니다.");
				break;
			}
		}
		scan.close();		
	}

}
