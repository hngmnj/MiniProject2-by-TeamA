package test;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class BusinessLogic {
	
	static ConfigVO config;
	static LibraryDAO dao = new LibraryDAO();
	
	public BusinessLogic(){
		Config cf = new Config();
		try {
			config = cf.getConfig();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	// 0-1. CSV파일 입력 (csv -> DB)
	public void csvToDB() throws IOException, SQLException {
		CsvReader cr = new CsvReader();
		cr.BookReader();
		cr.StudentReader();
	}
	
	//0-2. config 수정
	public boolean setConfig(int brrw_period, int brrw_max, int stdrsv_max, int bookrsv_max, String pw) throws SQLException {
		boolean flag = false;
		ConfigVO config = new ConfigVO(brrw_period, brrw_max, stdrsv_max, bookrsv_max, pw);
		flag = dao.insertConfig(config);
		return flag;
	}

	// 1-1. 도서 목록
	public void bookList() throws SQLException {
		ArrayList<BookVO> list =  dao.selectBook();
		System.out.println("책 번호\t|\t책 이름\t\t|\t저자\t|\t대여 가능 여부\t");
		for(BookVO vo : list) {
			System.out.println(vo.getBkNo()+"\t\t"+vo.getBkName()+"\t\t"+vo.getAuthor()+"\t\t"+vo.getBrrwYN());
		}
		System.out.println("");
	}
	
	// 1-2. 도서 등록
	public void bookAdd() throws SQLException {
		Scanner sc = new Scanner(System.in);
		ArrayList<BookVO> list = new ArrayList<BookVO>();
		while (true) {
            System.out.println("등록할 신규 도서번호를 입력해주세요 >>>");
            int bkNo = Integer.parseInt(sc.nextLine());
            String bkName;
            String author;
            int price;
            String prchDate;
            boolean flag;
            System.out.println("제목 입력 >>>");
            bkName = sc.nextLine();
            System.out.println("지은이 입력 >>>");
            author = sc.nextLine();
            System.out.println("가격 입력 >>>");
            price = Integer.parseInt(sc.nextLine());
            System.out.println("구매날짜 입력(yyyyMMdd) >>>");
            prchDate = sc.nextLine();
            BookVO vo = new BookVO(bkNo, bkName, author, price, prchDate, 0, "Y");
            list.add(vo);
            flag = dao.BookInsert(list);
            if (flag) {
            	System.out.println("도서 등록 완료");
            	break;
            } else {
            	System.out.println("해당 도서가 존재하지 않습니다. 도서 번호를 다시 입력하세요.");
            }  
        } 
	}
	
	// 1-3.책 정보 수정
    public void updateBook() throws SQLException {
    	Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("수정 할 책의 번호를 입력해주세요 >>>");
            int bkNo = Integer.parseInt(sc.nextLine());
            String bkName;
            String author;
            boolean flag;
            System.out.println("제목 입력 >>>");
            bkName = sc.nextLine();
            System.out.println("지은이 입력 >>>");
            author = sc.nextLine();
            flag = dao.updateBookInfo(bkNo, bkName, author);
            if (flag) {
            	System.out.println("도서 수정 완료");
            	break;
            } else {
            	System.out.println("해당 도서가 존재하지 않습니다. 도서 번호를 다시 입력하세요.");
            }  
        } 
    }
        
    // 2-1.도서대여
	public void borrowBook(int stdNo, int bkNo) throws SQLException {
		BorrowBook bb = new BorrowBook(stdNo, bkNo);
		boolean borrowable = false;

		borrowable = bb.checkBan();
		if (borrowable) {
			bb.borrowCancell();
			System.out.println("대출정지된 학생입니다.");
		} else {
			borrowable = bb.checkUnreturn();
			if (borrowable) {
				bb.borrowCancell();
				System.out.println("미반납도서 중 연체도서가 있습니다.");
			} else {
				borrowable = bb.checkBrrwAble();
				if (!borrowable) {
					bb.borrowCancell();
					System.out.println("도서대여는 "+config.getBrrw_max()+"권까지 가능합니다.");
				} else {
					borrowable = bb.checkHaveBook();
					if (borrowable) {
						bb.borrowConfirm();
						System.out.println("도서대여가 완료되었습니다.");
					} else {
						System.out.println("해당 도서는 모두 대여중 입니다. 예약하시겠습니까?  >> Y/N");
						Scanner scan = new Scanner(System.in);
						String choice = scan.nextLine();
						if (choice.toUpperCase().equals("Y")) {
							Boolean reservationable = false;
							ReservationBook rb = new ReservationBook(stdNo, bkNo);
							reservationable = rb.checkRsvCnt();
							if (!reservationable) {
								rb.reservationCancell();
								System.out.println("도서예약은 "+config.getStdrsv_max()+"권까지 가능합니다.");
							} else {
								reservationable = rb.checkRsvPeople();
								if (!reservationable) {
									rb.reservationCancell();
									System.out.println("해당 도서의 예약인원은"+config.getBrrw_max()+"명까지 가능합니다.");
								} else {
									reservationable = rb.checkBrrwOrRsv();						
									if (reservationable) {
										rb.reservationCancell();
										System.out.println("학생이 해당 도서를 이미 대여 또는 예약 중 입니다.");
									} else {
										rb.reservationConfirm();
										System.out.println("도서예약이 완료되었습니다.");
									}
								}
							}
						} else if (choice.equals("N")) {
							bb.borrowCancell();
							System.out.println("도서 대여 및 예약이 취소되었습니다.");
						}
					}
				}
			}
		}
	}

	// 2-2.도서 반납
	public void returnBook(int stdNo, int bkNo) throws SQLException {
		ReturnBook rb = new ReturnBook(stdNo, bkNo);
		boolean unborrowable = rb.checkUnreturn();
		boolean returnable = rb.checkHaveBook();
		
		if (!unborrowable) {
			if (returnable) {
				System.out.println("도서반납이 완료되었습니다.");
				rb.returnConfirm();
			}
		} else {
			unborrowable = rb.checkBan();
			if (unborrowable) {
				System.out.println("대출정지일자가 갱신되었습니다.");
				rb.updateBan();
				rb.returnConfirm();
			} else {
				System.out.println("대출정지일자가 추가되었습니다.");
					rb.newBan();
					rb.returnConfirm();
				}
			}
	
		}
	
	// 2-3. 대여현황
	public void ledgerStatus() throws SQLException {
		ArrayList<LedgerVO> list = new ArrayList<LedgerVO>();
		list = dao.selectLedger();
		System.out.println("No.\t책번호\t대여일\t\t반납예정일\t\t반납일\t\t반납여부\t대여회원");
		for (LedgerVO vo : list) {
			
			System.out.println(vo.getSeq()+"\t"+vo.getBkNo()+"\t"+vo.getBrrwDate()+"\t"+vo.getExpDate()+"\t"+vo.getRtrnDate()+"\t"+vo.getRtrnYN()+"\t"+vo.getStdNo());
		}
	}
	
	// 3-1. 회원목록
	 public void selectStudentAll() throws SQLException {
         ArrayList<StudentVO> list =  new ArrayList<StudentVO>();
         list = dao.selectStudentAll();
         System.out.println("학번\t\t|\t이름\t|\t전공\t|\t나이\t|\t예약가능여부\t|대출가능여부\t|정지일수");
         for(StudentVO vo : list) {
            System.out.println(vo.getStdNo()+"\t\t"+vo.getStdName()+"\t\t"+vo.getMajor()+"\t\t"+vo.getAge()+"\t\t"
         +vo.getRsvCnt()+"\t\t"+vo.getBrrwCnt()+"\t\t"+vo.getStopDate());
         }
         System.out.println("");
      }

	// 3-2. 회원등록
	public void registStd(int StdNo, String StdName, String Major, int Age) throws SQLException {
		boolean flag = false;
		StudentVO std = new StudentVO(StdNo, StdName, Major, Age, 0, 0, "0");
		ArrayList<StudentVO> list = new ArrayList<StudentVO>();
		list.add(std);
		flag = dao.stdRegist(list);
		if(flag) {
			System.out.println("회원등록을 성공하였습니다");
		} else {
			System.out.println("회원등록을 실패하였습니다");
		}
	}
	
	// 3-3. 회원수정
	public void editStd(int StdNo, String StdName, String Major, int Age) throws SQLException {
		boolean flag = false;
		flag = dao.updateStd(StdNo, StdName, Major, Age);
		if(flag) {
			System.out.println("회원수정을 성공하였습니다");
		} else {
			System.out.println("회원수정을 실패하였습니다");
		}
	}
}
