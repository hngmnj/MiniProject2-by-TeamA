package test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class LibraryDAO {
	
	// config 설정값 로드
	public ConfigVO selectConfig() throws SQLException {
		ConfigVO config = null;
		Connection con = ConnectionManager.getConnection();
		String sql = "select * from config order by insert_time desc limit 1";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		rs.next();
		config = new ConfigVO(rs.getInt(2),rs.getInt(3),rs.getInt(4),rs.getInt(5),rs.getString(6));
		ConnectionManager.closeConnection(rs, pstmt, con);
		return config;
	}
	
	// 설정 등록
	public boolean insertConfig(ConfigVO vo) throws SQLException {
		boolean flag = false;
		ConfigVO config = vo;
		Connection con = ConnectionManager.getConnection();
		String sql = "insert into config(brrw_period,brrw_max,stdrsv_max,bookrsv_max,pw)"
				+ "values(?,?,?,?,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		int affectedCount = 0;	
			pstmt.setInt(1, config.getBrrw_period());
			pstmt.setInt(2, config.getBrrw_max());
			pstmt.setInt(3, config.getStdrsv_max());
			pstmt.setInt(4, config.getBookrsv_max());
			pstmt.setString(5, config.getPw());	
			affectedCount = pstmt.executeUpdate();
		if (affectedCount>0) {
			flag = true;
		}
		return flag;
	}
	
	// 책 등록
	public boolean BookInsert(ArrayList<BookVO> list) throws SQLException {
		boolean flag = false;
		Connection con = ConnectionManager.getConnection();
		String sql = "insert into book(book_no,book_name,author,price,prch_date,rsv_people,brrw_yn) "
				+ "values(?,?,?,?,?,?,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		
		int affectedCount = 0;
		for(BookVO vo : list) {
			
			pstmt.setInt(1,vo.getBkNo());
			pstmt.setString(2, vo.getBkName());
			pstmt.setString(3, vo.getAuthor());
			pstmt.setInt(4, vo.getPrice());
			pstmt.setString(5, vo.getPrchDate());
			pstmt.setInt(6, vo.getRsvPeople());
			pstmt.setString(7,vo.getBrrwYN());
			
			affectedCount = pstmt.executeUpdate();
			
		}
		if (affectedCount>0) {
			flag = true;
		}
		return flag;
		}
	
	// 학생 신규 등록
	public boolean stdRegist(ArrayList<StudentVO> list) throws SQLException {
		boolean flag = false;
		Connection con = ConnectionManager.getConnection();
		String sql = "insert into student(std_No,std_Name,major,age,rsv_cnt,brrw_cnt,stop_date) "+ "values(?,?,?,?,?,?,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		
		int affectedCount = 0;
		for(StudentVO vo : list) {
			
			pstmt.setInt(1,vo.getStdNo());
			pstmt.setString(2, vo.getStdName());
			pstmt.setString(3, vo.getMajor());
			pstmt.setInt(4, vo.getAge());
			pstmt.setInt(5, 0);
			pstmt.setInt(6, 0);
			pstmt.setString(7, "0");
			
			affectedCount = pstmt.executeUpdate();
		}
		if (affectedCount>0) {
			flag = true;
		}
		return flag;
	}

	//대출장부 추가
	public boolean insertBrrwBook(ArrayList<LedgerVO> list) throws SQLException {
		boolean flag = false;
		Connection con = ConnectionManager.getConnection();
		String sql = "insert into ledger(brrw_date,exp_date,std_no,book_no,rtrn_date,rtrn_yn) values (?,?,?,?,?,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);

		int affectedCount = 0;
		for(LedgerVO vo : list) {

			pstmt.setString(1, vo.getBrrwDate());
			pstmt.setString(2, vo.getExpDate());
			pstmt.setInt(3, vo.getStdNo());
			pstmt.setInt(4, vo.getBkNo());
			pstmt.setString(5, vo.getRtrnDate());
			pstmt.setString(6, vo.getRtrnYN());
			affectedCount = pstmt.executeUpdate();
		}
		if (affectedCount>0) {
			flag = true;
		}
		ConnectionManager.closeConnection(null, pstmt, con);
		System.out.println("대출장부 추가");
		return flag;
	}
	//예약장부 추가
	public boolean insertRsvBook(ArrayList<ReservationVO> list) throws SQLException {
		boolean flag = false;
		Connection con = ConnectionManager.getConnection();
		String sql = "insert into reservation(rsv_date,std_no,book_no,rsv_yn) values (?,?,?,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		int affectedCount = 0;
		for(ReservationVO vo : list) {
			pstmt.setString(1, vo.getRsvDate());
			pstmt.setInt(2, vo.getStdNo());
			pstmt.setInt(3, vo.getBkNo());
			pstmt.setString(4, vo.getRsvYN());
			affectedCount = pstmt.executeUpdate();
		}
		if (affectedCount>0) {
			flag = true;
		}
		ConnectionManager.closeConnection(null, pstmt, con);
		System.out.println("예약장부 추가");
		return flag;
	}
	//대출장부 전체 조회
	public ArrayList<LedgerVO> selectLedger() throws SQLException {
		ArrayList<LedgerVO> list = new ArrayList<LedgerVO>();
		Connection con = ConnectionManager.getConnection();
		String sql = "select * from ledger";
		PreparedStatement pstmt = con.prepareStatement(sql);

		ResultSet rs = pstmt.executeQuery();
		LedgerVO vo = null;
		while (rs.next()) {
			vo = new LedgerVO(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),
					rs.getInt(5),rs.getString(6),rs.getString(7));
			list.add(vo);
		}
		ConnectionManager.closeConnection(rs, pstmt, con);
		return list;
	}
	//학번으로 대출장부 조회
	public ArrayList<LedgerVO> selectLedger(int stdNo) throws SQLException {
		ArrayList<LedgerVO> list = new ArrayList<LedgerVO>();
		Connection con = ConnectionManager.getConnection();
		String sql = "select * from ledger where std_no=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, stdNo);
		ResultSet rs = pstmt.executeQuery();
		LedgerVO vo = null;
		while (rs.next()) {
			vo = new LedgerVO(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),
					rs.getInt(5),rs.getString(6),rs.getString(7));
			list.add(vo);
		}
		ConnectionManager.closeConnection(rs, pstmt, con);
		return list;
	}
	//예약장부 조회
	public ArrayList<ReservationVO> selectReserveBook() throws SQLException {
		ArrayList<ReservationVO> list = new ArrayList<ReservationVO>();
		Connection con = ConnectionManager.getConnection();
		String sql = "select * from reservation";
		PreparedStatement pstmt = con.prepareStatement(sql);

		ResultSet rs = pstmt.executeQuery();
		ReservationVO vo = null;
		while (rs.next()) {
			vo = new ReservationVO(rs.getInt(1),rs.getString(2),rs.getInt(3),
					rs.getInt(4),rs.getString(5));
			list.add(vo);
		}
		ConnectionManager.closeConnection(rs, pstmt, con);
		return list;
	}
	
	// 회원목록
		public ArrayList<StudentVO> selectStudentAll() throws SQLException {
			ArrayList<StudentVO> list = new ArrayList<StudentVO>();
			Connection con = ConnectionManager.getConnection();
			String sql = "select * from student";
			PreparedStatement pstmt = con.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			StudentVO vo = null;
			while (rs.next()) {
				vo = new StudentVO(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5),rs.getInt(6),rs.getString(7));
				list.add(vo);
			}
			return list;
		}
	//학생정보 조회
	public ArrayList<StudentVO> selectStudent() throws SQLException {
		ArrayList<StudentVO> list = new ArrayList<StudentVO>();
		Connection con = ConnectionManager.getConnection();
		String sql = "select * from student";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		StudentVO vo = null;
		while (rs.next()) {
			vo = new StudentVO(rs.getInt(1), rs.getString(2),rs.getString(3),rs.getInt(4),
					rs.getInt(5),rs.getInt(6),rs.getString(7));
			list.add(vo);
		}
		ConnectionManager.closeConnection(rs, pstmt, con);
		return list;
	}
	//학번으로 학생정보 조회
	public StudentVO selectStudent(int stdNo) throws SQLException {
		StudentVO vo = null;
		Connection con = ConnectionManager.getConnection();
		String sql = "select * from student where std_no = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, stdNo);
		ResultSet rs = pstmt.executeQuery();
		while (rs.next()) {
			vo = new StudentVO(rs.getInt(1), rs.getString(2),rs.getString(3),rs.getInt(4),
					rs.getInt(5),rs.getInt(6),rs.getString(7));
		}
		ConnectionManager.closeConnection(rs, pstmt, con);
		return vo;
	}
	//도서정보 조회
	public ArrayList<BookVO> selectBook() throws SQLException {
		ArrayList<BookVO> list = new ArrayList<BookVO>();
		Connection con = ConnectionManager.getConnection();
		String sql = "select * from book";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		BookVO vo = null;
		while (rs.next()) {
			vo = new BookVO(rs.getInt(1),rs.getString(2),rs.getString(3),
					rs.getInt(4),rs.getString(5),rs.getInt(6),rs.getString(7));
			list.add(vo);
		}
		ConnectionManager.closeConnection(rs, pstmt, con);
		return list;
	}
	//책 분류로 도서정보 조회
	public BookVO selectBook(int bkNo) throws SQLException {
		BookVO vo = null;
		Connection con = ConnectionManager.getConnection();
		String sql = "select * from book where book_no = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, bkNo);
		ResultSet rs = pstmt.executeQuery();
		while (rs.next()) {
			vo = new BookVO(rs.getInt(1),rs.getString(2),rs.getString(3),
					rs.getInt(4),rs.getString(5),rs.getInt(6),rs.getString(7));
		}
		ConnectionManager.closeConnection(rs, pstmt, con);
		return vo;
	}

	//학번으로 예약정보 조회
	public ArrayList<ReservationVO> selectStdRsv(int stdNo) throws SQLException {
		ArrayList<ReservationVO> list = new ArrayList<ReservationVO>();
		Connection con = ConnectionManager.getConnection();
		String sql = "select * from reservation where std_no = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, stdNo);
		ResultSet rs = pstmt.executeQuery();
		ReservationVO vo = null;
		while (rs.next()) {
			vo = new ReservationVO(rs.getInt(1),rs.getString(2), rs.getInt(3),rs.getInt(4),rs.getString(5));
			list.add(vo);
		}
		ConnectionManager.closeConnection(rs, pstmt, con);
		return list;
	}

	//대여가능여부 갱신
	public boolean updateBook(String brrwYN, int bkNo) throws SQLException {
		boolean flag = false;
		Connection con = ConnectionManager.getConnection();
		Statement stmt = null;
		DateTimeService dt = new DateTimeService();
		stmt = con.createStatement();
		String sql1 = "update student set brrw_cnt = brrw_cnt - 1 where "
				+ "std_no = (SELECT std_no FROM ledger where rtrn_yn = 'N' and book_no = "+bkNo+")";
		String sql2 = "update book set brrw_yn='"+brrwYN+"' where book_no="+ bkNo;
		String sql3 = "update ledger set rtrn_yn = 'Y' ,rtrn_date ="+dt.getNow()+" where rtrn_yn = 'N' and book_no = "+bkNo;
		int affectedCount = stmt.executeUpdate(sql1);
		int affectedCount2 = stmt.executeUpdate(sql2);
		int affectedCount3 = stmt.executeUpdate(sql3);
		if (affectedCount>0 && affectedCount2 > 0 && affectedCount3 > 0) {
			flag = true;
		}
		ConnectionManager.closeConnection(null, stmt, con);
		return flag;
	}


	public boolean updateBookBrrwYn(String brrwYN, int bkNo) throws SQLException {
		boolean flag = false;
		Connection con = ConnectionManager.getConnection();
		Statement stmt = null;
		DateTimeService dt = new DateTimeService();
		stmt = con.createStatement();
		String sql2 = "update book set brrw_yn='"+brrwYN+"' where book_no="+ bkNo;
		int affectedCount2 = stmt.executeUpdate(sql2);
		if (affectedCount2 > 0) {
			flag = true;
		}
		ConnectionManager.closeConnection(null, stmt, con);
		return flag;
	}

	//학번으로 대출정지일 갱신
	public boolean updateStopDate(int bkNo, int stdNo) throws SQLException {
		DateTimeService dt = new DateTimeService();
		boolean flag = false;
		Connection con = ConnectionManager.getConnection();
		Statement stmt = null;
		String sql = "update student "
				+ "set stop_date = cast(date_format(datediff(cast("+dt.getNow()+" as datetime),"
				+ "cast((select rtrn_date from ledger where book_no = "+bkNo+") as datetime))"
				+ "as varchar(8))) "
				+ "where book_no="+ stdNo;

		stmt = con.createStatement();
		int affectedCount = stmt.executeUpdate(sql);
		if (affectedCount>0) {
			flag = true;
		}
		ConnectionManager.closeConnection(null, stmt, con);
		return flag;
	}

	//학번으로 예약권수 갱신
	public boolean updateRsvBks(int stdNo) throws SQLException {
		boolean flag = false;
		Connection con = ConnectionManager.getConnection();
		Statement stmt = null;
		String sql = "update student "
				+ " set rsv_cnt = rsv_cnt - 1 "
				+ " where std_no = "+stdNo;

		stmt = con.createStatement();
		int affectedCount = stmt.executeUpdate(sql);
		if (affectedCount>0) {
			flag = true;
		}
		ConnectionManager.closeConnection(null, stmt, con);
		return flag;
	}
	//학번으로 대출권수 갱신
	public boolean updateBrrwCount(int stdNo) throws SQLException {
		boolean flag = false;
		Connection con = ConnectionManager.getConnection();
		Statement stmt = null;
		String sql = "update student "
				+ "set brrw_cnt = brrw_cnt +1 "
				+ "where std_no = "+stdNo;

		stmt = con.createStatement();
		int affectedCount = stmt.executeUpdate(sql);
		if (affectedCount>0) {
			flag = true;
		}
		ConnectionManager.closeConnection(null, stmt, con);
		return flag;
	}
	//책번호로 예약인원 갱신
	public boolean updateRsvPeople(int bkNo) throws SQLException {
		boolean flag = false;
		Connection con = ConnectionManager.getConnection();
		Statement stmt = null;
		String sql = "update book "
				+ "set rsv_people = rsv_people +1 "
				+ "where book_no = "+bkNo;

		stmt = con.createStatement();
		int affectedCount = stmt.executeUpdate(sql);
		if (affectedCount>0) {
			flag = true;
		}
		ConnectionManager.closeConnection(null, stmt, con);
		return flag;
	}
	//도서 수정인가?
	public boolean updateBookInfo(int bkNo,String bkName, String author) throws SQLException {
		boolean flag = false;
		Connection con = ConnectionManager.getConnection();
		Statement stmt = null;
		String sql = "update book "
				+"set book_name='"+bkName+"',author='"+author + "'"
				+" where book_no = "+bkNo;
		stmt = con.createStatement();
		int affectedCount = stmt.executeUpdate(sql);
		if (affectedCount>0) {
			flag = true;
		}
		ConnectionManager.closeConnection(null, stmt, con);
		return flag;
	}
	
	//회원(학생)수정
	public boolean updateStd(int stdNo, String stdName, String major, int age) throws SQLException {
		boolean flag = false;
		Connection con = ConnectionManager.getConnection();
		Statement stmt = null;
		String sql = "update student "
				+"set std_name='"+stdName+"',age="+age+",major='"+major + "'"
				+" where std_no = "+stdNo;
		stmt = con.createStatement();
		int affectedCount = stmt.executeUpdate(sql);
		if (affectedCount>0) {
			flag = true;
		}
		ConnectionManager.closeConnection(null, stmt, con);
		return flag;
	}
	
	

}