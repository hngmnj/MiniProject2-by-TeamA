package test;

public class ConfigVO {
	
	private int brrw_period;
	private int brrw_max;
	private int stdrsv_max;
	private int bookrsv_max;
	private String pw;
	
	public ConfigVO(int brrw_period, int brrw_max, int stdrsv_max, int bookrsv_max, String pw) {
		this.brrw_period = brrw_period;
		this.brrw_max = brrw_max;
		this.stdrsv_max = stdrsv_max;
		this.bookrsv_max = bookrsv_max;
		this.pw = pw;
	}
	
	public ConfigVO(String data) {

		System.out.println(data);
		String[] temp = data.split(",");
		this.brrw_period = Integer.parseInt(temp[0].trim());
		this.brrw_max = Integer.parseInt(temp[1].trim());
		this.stdrsv_max = Integer.parseInt(temp[2].trim());
		this.bookrsv_max = Integer.parseInt(temp[3].trim());
		this.pw = temp[4].trim();

	}

	public int getBrrw_period() {
		return brrw_period;
	}

	public void setBrrw_period(int brrw_period) {
		this.brrw_period = brrw_period;
	}

	public int getBrrw_max() {
		return brrw_max;
	}

	public void setBrrw_max(int brrw_max) {
		this.brrw_max = brrw_max;
	}

	public int getStdrsv_max() {
		return stdrsv_max;
	}

	public void setStdrsv_max(int stdrsv_max) {
		this.stdrsv_max = stdrsv_max;
	}

	public int getBookrsv_max() {
		return bookrsv_max;
	}

	public void setBookrsv_max(int bookrsv_max) {
		this.bookrsv_max = bookrsv_max;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

}
